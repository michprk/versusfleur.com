# Handoff: Versus — site B2B (fleuriste, Bruxelles)

## Overview
One-page B2B landing site for **Versus**, circular/eco-responsible florist at Rue Haute 158, 1000 Bruxelles (Marolles). Goal: **conversion** — push companies to estimate a budget and send a quote request (abonnement bureaux, cadeaux d'affaires, événements, team building floral). Language: French.

## About the Design Files
`Versus B2B.dc.html` is a **design reference built in HTML** (opens directly in a browser; `support.js` is the prototype runtime). It is not production code. Recreate it in the target stack (e.g. Next.js/React + Tailwind, Astro, WordPress theme…) using that stack's patterns. The logic class inside the file (`class Component`) documents the exact estimator math and state.

## Fidelity
**High-fidelity.** Final colors, type, spacing, copy, interactions. Recreate pixel-close. No photography by request — the site is type-driven.

## Real business data (from versusfleurs.be)
- Bouquets: **Un peu 35 €**, **Beaucoup 50 €** (le plus demandé), **Passionnément 70 €**, **À la folie dès 70 €** (sur-mesure)
- Livraison Bruxelles: **env. 15–20 €** selon la localité (non incluse). Retrait boutique **gratuit**
- Atelier floral: **1h30, 55 €/pers.**, réservation individuelle via Wecandoo: https://wecandoo.be/atelier/bruxelles-daphne-ellea-fleurs-fraiches-bouquet
- Contact: +32 2 681 17 34 · info@versusfleurs.be · Instagram @versus_bxl · facebook.com/VersusFleursBrussels
- Horaires: Lun fermé · Mar 14h30–18h · Mer–Ven 10h–18h · Sam 10h–19h · Dim 10h–16h30
- Fondatrice: Daphné Marceau. Atelier dans une ancienne chapellerie Art Nouveau (1905). Membre Slow Flowers Belgique, label Made in Brussels, article RTBF.
- ⚠ B2B formulas (subscription frequencies, private team workshops) are proposals derived from public prices — confirm with the client.

## Design Tokens
Colors (only these):
- `--cream` #f7f4e8 — page canvas, text on violet/black
- `--ink` #000000 — text, borders, primary buttons
- `--stone` #c6c3ba — secondary surfaces (info chips, estimation summary), hover on ± buttons
- `--violet` #643aed — the single accent: hero field, featured cards, estimator result, final CTA block

Typography:
- Display: **Anton** 400 (Google Fonts), uppercase, line-height 0.85, letter-spacing 0. Only ≥ 40px. (Substitute for fkScreamer/Druk.)
- Body/UI: **Hanken Grotesk** 400/500/600/700, 16px/1.4, letter-spacing −0.01em.
- Scale: H1 `clamp(64px,12vw,184px)`; H2 `clamp(52px,7.5vw,120px)`; card H3 44px (offres) / `clamp(34px,3.2vw,48px)` (tarifs); prices 96px Anton; stats 64px; step numbers 120px; body-lg 18–22px; captions/tags 14px 600.

Spacing & shape:
- Section padding: top `clamp(64px,9vw,128px)`, horizontal `clamp(20px,4vw,48px)`. Full-bleed, no max-width container.
- Card padding 24px; grid gap 20px; big blocks padding `clamp(28px,5vw,64px)`.
- **Radius 20px everywhere** (buttons, cards, tags, inputs, blocks). Hero: bottom corners only.
- **No shadows.** Elevation = 1px #000 border or violet/black surface.

Buttons:
- Primary: bg #000, text cream, 1px #000, radius 20, padding 14–16px × 20–26px, 16–17px/600. Hover → bg/border violet.
- On violet/black: bg cream, text #000; hover → bg #000, text cream.
- Ghost: transparent, 1px currentColor; hover fills.
- Focus-visible: 2px solid #643aed outline, offset 2px.

## Screens / Sections (top → bottom)
1. **Sticky header** (cream, 1px black bottom border): wordmark "VERSUS" (Anton 30px, tracking .04em) + "Fleuristerie · Marolles"; nav links (Offres entreprises, Tarifs, Team building, FAQ) hidden < 980px; phone ghost pill (hidden < 980px); black "Demander un devis" → scrolls to #devis.
2. **Hero** (violet field): 2 tag pills (outlined cream) — "Fleurs pour entreprises · Bruxelles" and **live open status** (Brussels time; pulsing cream dot when open, "Atelier ouvert · jusqu'à 18h" / "Atelier fermé · devis en ligne 24/7"). H1 "Des fleurs belges / pour [dès 35 €] votre / entreprise." — the price is an inline cream pill inside the headline (0.42em). Lead paragraph + CTAs "Estimer mon budget en 1 minute →" (cream) and "Voir les tarifs" (ghost).
3. **Marquee** (Anton 40px, 38s linear loop, violet ✺ separators): Producteurs belges · Culture raisonnée · Fraîches & séchées · Économie circulaire · Atelier ouvert rue Haute.
4. **#offres — 4 offer cards** (auto-fit grid, min 280px): Abonnement floral (dès 35 €/passage), Cadeaux d'affaires (35–70 €/bouquet), Événements & décor (dès 70 €/pièce), Team building floral (55 €/pers., violet card). Each CTA preselects the estimator need and scrolls to #devis.
5. **#tarifs — 4 bouquet cards** with big Anton prices; "Beaucoup" has a black "Le plus demandé" badge and black CTA; "À la folie" is violet. "Ajouter à mon devis" preselects that format. Below: 3 stone info chips (livraison, retrait, fraîches/séchées).
6. **#atelier** (black rounded block): H2, 3 stat boxes (1h30 / 55 € / 1 bouquet), 3 steps, CTA "Réserver pour mon équipe →" (violet) + Wecandoo link.
7. **Pourquoi Versus**: centered H2 "Circulaire, locale et écoresponsable", 3 columns with top rule, trust pills.
8. **Méthode**: 3 outlined cards, violet numerals 1–3 (Brief → Proposition → Livraison/retrait).
9. **#devis — Estimator + form** (2 columns, auto-fit min 420px):
   - Left: need segmented pills; format picker (abonnement/cadeaux only); frequency (abonnement only); quantity stepper; pickup checkbox (not for atelier); violet result card with price range, breakdown lines, disclaimer.
   - Right: form (Nom*, Entreprise, Email pro*, Téléphone, Besoin textarea) + stone "Estimation jointe" summary + submit "Recevoir ma proposition →". Success state: "Merci {prénom}." + summary + call/new request.
10. **#faq**: accordion, 5 items, first open, single-open behavior, +/− indicator.
11. **Final CTA** (violet block): "Fleurissons vos bureaux." + devis/phone/email buttons, address, hours, socials. Footer line.
12. **Floating CTA**: appears after scrollY > 700 (hidden after form sent). Black pill "Estimer mon budget [dès 35 €]" bottom-right; full-width bottom bar < 980px.

## Estimator logic (exact)
Prices: unpeu 35, beaucoup 50, passion 70, folie 70 ("dès"). Delivery 15–20 € per delivery; 0 if pickup.
- **abonnement**: passages/month = hebdo 4 | bimensuel 2 | mensuel 1. flowers = price × qty × passages. total = flowers + [15..20] × passages. Period "Par mois". Default qty 1.
- **cadeaux**: flowers = price × qty; delivery = [15..20] × qty (one per recipient). Default qty 5.
- **evenement**: format forced to À la folie; "dès" (70 × qty + 15 unless pickup). Default qty 4.
- **atelier**: 55 × participants, min 2. Default 8.
- Display: "min – max €" or "dès X €" when À la folie / open-ended. Format numbers fr-BE with regular spaces.
- Summary string (sent with form): e.g. "Abonnement — 1 × Beaucoup, chaque semaine · 260 – 280 € / mois".

## State
`need, format, freq, qty, pickup, form{name,company,email,phone,msg}, sent, err, faq (open index), scrolled (bool), viewport width, now (clock, refresh 60s)`.

## Validation / submission
Name required; email `^\S+@\S+\.\S+$`. Errors inline in violet 14px/600. **The prototype does not submit anywhere** — wire to email/CRM (e.g. Formspree, Resend, HubSpot) and include the estimator summary + selected need. Add analytics events on every CTA click and form submit.

## Responsive
Fluid grids `repeat(auto-fit,minmax(min(100%,Npx),1fr))`; nav collapses < 980px; type scales with clamp().

## Assets
None (no photos by request). Fonts: Google Fonts Anton + Hanken Grotesk. Logo: use client's real wordmark (versusfleurs.be) if available.

## Files
- `Versus B2B.dc.html` — full design + logic (open in a browser; requires `support.js` alongside)
- `support.js` — prototype runtime only, not needed in production
